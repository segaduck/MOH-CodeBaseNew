﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using Renci.SshNet;
using log4net;

namespace ES.Areas.BACKMIN.Utils
{
    public class SFTPUtils
    {
        private SftpClient sftp;
        protected static readonly ILog logger = ES.Utils.LogUtils.GetLogger();
        /// <summary>
        /// SFTP連線狀態
        /// </summary>
        public bool Connected { get { return sftp.IsConnected; } }

        /// <summary>
        /// SFTP工具
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        /// <param name="user"></param>
        /// <param name="pwd"></param>
        public SFTPUtils(string ip, string port, string user, string pwd)
        {
            sftp = new SftpClient(ip, Int32.Parse(port), user, pwd);
        }

        /// <summary>
        /// 開啟SFTP連線
        /// </summary>
        /// <returns></returns>
        public bool Connect()
        {
            try
            {
                if (!Connected)
                {
                    int max = 5;
                    for (int i = 1; i <= max; i++)
                    {
                        try
                        {
                            sftp.Connect();
                            break;
                        }
                        catch (Exception e)
                        {
                            logger.Warn(String.Format("SFTP連線失敗第{0}次，錯誤訊息：{1}", i, e.Message));
                            if (i >= max) throw e;
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("SFTP連線失敗，錯誤訊息：{0}", ex.Message));
            }
        }

        /// <summary>
        /// 中斷SFTP連線
        /// </summary>
        public void Disconnect()
        {
            try
            {
                if (sftp != null && Connected)
                {
                    sftp.Disconnect();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("中斷SFTP連線失敗，錯誤訊息：{0}", ex.Message));
            }
        }

        /// <summary>
        /// 上傳本地檔案
        /// </summary>
        /// <param name="localPath"></param>
        /// <param name="remotePath"></param>
        public void Put(string localPath, string remotePath)
        {
            try
            {
                using (var file = File.OpenRead(localPath))
                {
                    Connect();
                    sftp.UploadFile(file, remotePath);
                    //Disconnect();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("上傳本地檔案失敗，錯誤訊息：{0}", ex.Message));
            }
        }

        /// <summary>
        /// 取得遠端檔案
        /// </summary>
        /// <param name="remotePath"></param>
        /// <param name="localPath"></param>
        public void Get(string remotePath, string localPath)
        {
            try
            {
                Connect();
                var byt = sftp.ReadAllBytes(remotePath);
                //Disconnect();
                File.WriteAllBytes(localPath, byt);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("取得遠端檔案失敗，錯誤訊息：{0}", ex.Message));
            }

        }

        /// <summary>
        /// 刪除遠端檔案
        /// </summary>
        /// <param name="remoteFile"></param>
        public void Delete(string remoteFile)
        {
            try
            {
                Connect();
                sftp.Delete(remoteFile);
                //Disconnect();
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("刪除遠端檔案失敗，錯誤訊息：{0}", ex.Message));
            }
        }

        /// <summary>
        /// 取得遠端檔案列表
        /// </summary>
        /// <param name="remotePath"></param>
        /// <param name="fileSuffix"></param>
        /// <returns></returns>
        public List<string> GetFileList(string remotePath)
        {
            try
            {
                Connect();
                var files = sftp.ListDirectory(remotePath);
                //Disconnect();
                List<string> list = new List<string>();

                foreach (var file in files)
                {
                    list.Add(file.Name);
                }
                return list;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("取得遠端檔案列表失敗，錯誤訊息：{0}", ex.Message));
            }
        }

        /// <summary>
        /// 取得遠端檔案列表
        /// </summary>
        /// <param name="remotePath"></param>
        /// <param name="fileSuffix"></param>
        /// <returns></returns>
        public List<string> GetFileList(string remotePath, string fileSuffix)
        {
            try
            {
                Connect();
                var files = sftp.ListDirectory(remotePath);
                //Disconnect();
                List<string> list = new List<string>();
                
                foreach (var file in files)
                {
                    string name = file.Name;
                    if (name.Length > (fileSuffix.Length + 1) && fileSuffix == name.Substring(name.Length - fileSuffix.Length))
                    {
                        list.Add(name);
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("取得遠端檔案列表失敗，錯誤訊息：{0}", ex.Message));
            }
        }

        /// <summary>
        /// 移動遠端檔案
        /// </summary>
        /// <param name="oldRemotePath"></param>
        /// <param name="newRemotePath"></param>
        public void Move(string oldRemotePath, string newRemotePath)
        {
            try
            {
                Connect();
                sftp.RenameFile(oldRemotePath, newRemotePath);
                //Disconnect();
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("移動遠端檔案失敗，錯誤訊息：{0}", ex.Message));
            }
        }
    }
}